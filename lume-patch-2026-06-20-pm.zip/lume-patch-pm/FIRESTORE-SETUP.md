# Firestore + Webhook Setup — Lume Live (2026-06-20)

This patch shifts the payment-access boundary from "what's in localStorage"
to "what's in Firestore, written only by a HMAC-verified webhook." Before
deploying, complete the steps below. They are one-time per environment.

Estimated time: 25–35 minutes.

---

## Step 1 — Enable Firestore on `lume-live-cf865`

1. Open the Firebase Console for the `lume-live-cf865` project.
2. Build → **Firestore Database** → Create database.
3. Pick mode: **production mode** (rules will be applied immediately).
4. Location: **asia-south1** (Mumbai) for India-resident data. **This cannot be changed later** — pick correctly the first time.
5. Wait for the database to provision (~30 seconds).

---

## Step 2 — Create a service account for the Vercel functions

1. Firebase Console → **Project Settings** → **Service accounts** tab.
2. Select **Node.js** SDK option.
3. Click **Generate new private key**. A JSON file downloads.
4. **Treat this file like a password** — anyone with it can read and write your entire Firestore. Do not commit it to git (`.gitignore` already excludes `.env*`, but the JSON file itself must not be saved into the repo).
5. Open the JSON in a text editor. You need three values from it:
   - `project_id` (will be `lume-live-cf865`)
   - `client_email` (looks like `firebase-adminsdk-xxx@lume-live-cf865.iam.gserviceaccount.com`)
   - `private_key` (a long PEM block starting with `-----BEGIN PRIVATE KEY-----`)

---

## Step 3 — Add the four secrets to Vercel

In the Vercel dashboard for the `lume-live-website` project: **Settings** → **Environment Variables**.

Add the following four variables, scoped to **Production** (and optionally Preview if you use preview deployments):

| Variable                     | Value                                                                                              |
| ---------------------------- | -------------------------------------------------------------------------------------------------- |
| `FIREBASE_PROJECT_ID`        | `lume-live-cf865`                                                                                  |
| `FIREBASE_CLIENT_EMAIL`      | the `client_email` from the JSON                                                                   |
| `FIREBASE_PRIVATE_KEY`       | the **entire** `private_key` string from the JSON, including the `-----BEGIN/END PRIVATE KEY-----` markers. Paste it as-is — Vercel preserves the `\n` escapes and the code unescapes them at runtime. |
| `CASHFREE_WEBHOOK_SECRET`    | see Step 5                                                                                         |

After saving, **redeploy** the project so the new env vars are picked up. Vercel does not hot-reload env vars into existing serverless functions.

---

## Step 4 — Deploy Firestore rules and indexes

From the repo root (where `firestore.rules` and `firestore.indexes.json` now live):

```bash
# Install Firebase CLI if you don't have it
npm install -g firebase-tools

# Sign in
firebase login

# Deploy rules
firebase deploy --only firestore:rules --project lume-live-cf865

# Deploy indexes (this can take 2-5 minutes to finish building in the background)
firebase deploy --only firestore:indexes --project lume-live-cf865
```

If the deploy command complains about missing `firebase.json`, create one in
the repo root with just:

```json
{
  "firestore": {
    "rules":   "firestore.rules",
    "indexes": "firestore.indexes.json"
  }
}
```

Then re-run the deploy commands.

**Watch the index build.** Firebase Console → Firestore → Indexes. The
`(uid ASC, status ASC)` composite index must show **Enabled** before the
`/api/cashfree/access` endpoint will work. If you deploy the site first,
the endpoint will return 500 with a "missing index" error in Vercel logs.

---

## Step 5 — Configure the Cashfree webhook

1. Cashfree dashboard → **Developers** → **Webhooks**.
2. Click **Add Webhook URL**.
3. URL: `https://lumelive.co.in/api/cashfree/webhook`
4. Events to subscribe (at minimum):
   - `PAYMENT_SUCCESS_WEBHOOK` (required)
   - `PAYMENT_FAILED_WEBHOOK` (recommended for observability)
   - `PAYMENT_USER_DROPPED_WEBHOOK` (recommended for funnel analysis)
5. Copy the **webhook secret** that Cashfree generates for this endpoint.
6. Paste it into the Vercel env var `CASHFREE_WEBHOOK_SECRET` and redeploy.

If you have both **sandbox** and **production** Cashfree accounts, configure
the webhook on **both**. The secret is different per environment.

---

## Step 6 — Smoke test in sandbox

After deploy, run through this end-to-end check before flipping production
traffic.

1. Set `CASHFREE_ENV=sandbox` in Vercel env vars temporarily (or use a
   preview deployment with sandbox values).
2. Sign in to lumelive.co.in with a real Firebase account.
3. Open `/assessment.html`, fill the intake, click **Pay Securely with Cashfree**.
4. In the sandbox checkout, use a test card or test UPI. Complete the payment.
5. Land on `/payment-return.html`. You should see:
   - "Checking Cashfree payment status..." for ~1-2 seconds
   - "Cashfree confirmed payment. Waiting for our records to sync..."
   - Then auto-redirect to the assessment
6. Open Firestore Console → `lumelens_orders` → you should see a document
   with `status: "PAID"`, the correct `uid`, `sku`, `amount`, and a
   `paid_at` timestamp.
7. In a NEW incognito window, sign in with a DIFFERENT Firebase account
   (or no account at all), open DevTools and run:

   ```js
   localStorage.setItem("lumeCashfreeAccess", JSON.stringify({
     "student-full-report": { status: "PAID" }
   }));
   location.reload();
   ```

   The assessment **must remain locked**. If it unlocks, the localStorage
   bypass is still live — file a bug.

8. In the Cashfree sandbox webhook dashboard, click **Resend** on the
   webhook that fired in step 6. Verify Firestore still shows ONE document
   for that order ID (not two) and `paid_at` did not change. This confirms
   idempotency.

9. Set `CASHFREE_ENV=production` back in Vercel env vars.

---

## What this patch changes — security model summary

| Surface                                | Before                                                                  | After                                                                       |
| -------------------------------------- | ----------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Source of truth for "is this paid?"    | `localStorage["lumeCashfreeAccess"]` — client-writable                  | Firestore `lumelens_orders/{id}` — server-only writes via Admin SDK         |
| Who can grant access                   | Anyone with DevTools                                                    | Only Cashfree → HMAC-verified webhook → Firebase Admin SDK                  |
| What happens if the user closes the tab | localStorage never written → support ticket                            | Webhook still fires → Firestore still updated → user re-signs-in and sees their paid status |
| PII exposure                           | `order-status` endpoint leaked name/phone/email to anyone with order_id | (Fixed in morning patch) `order-status` returns only status + amount        |
| Order ID guessability                  | Timestamp + 5 random base-36 chars                                      | (Fixed in morning patch) 32-char UUID hex, 122 bits of entropy              |
| Webhook replay protection              | No webhook at all                                                       | 5-minute replay window, idempotent Firestore transactions                   |

---

## What still isn't airtight (and why)

The PDF report is still generated client-side via jsPDF. An attacker who
gets past the assessment gate can in principle still complete the questions
and see the rendered report. The fix for that is server-side report
generation, deferred to a later phase — it's a bigger change and the actual
value of Lume Live is the counsellor debrief, not the auto-PDF.

What this patch does close: the trivial "paste one line in DevTools and
unlock everything" bypass. After this lands, an attacker needs to either
forge a Cashfree webhook (requires the secret), find a Firestore rules bug,
or compromise a paying user's Firebase session — all of which are real
attacker effort, not bored-teenager effort.

---

## Rollback plan

If anything breaks in production:

1. **Cashfree webhook firing but Firestore writes failing** — most likely
   missing or wrong service-account env vars. Check Vercel logs. The webhook
   returns 5xx so Cashfree will retry automatically once you fix the env vars.

2. **Access endpoint returning 500** — usually the composite index is still
   building. Wait 5 minutes, retry. If still failing, check Vercel logs for
   the message "Missing Firestore composite index" and re-run the deploy.

3. **All paid users locked out** — emergency rollback: redeploy the previous
   `cashfree-payments.js` (the one that reads localStorage). This restores
   access for users who completed payment under the old flow, at the cost of
   re-opening the bypass. Coordinate with new deploys ASAP.
