/*
  Shared Firebase Admin SDK initialiser for Lume Live serverless functions.

  Files under `api/_lib/` are NOT routed as Vercel functions (the underscore
  prefix is the convention for shared helpers). Functions under `api/cashfree/`
  pull this in with a relative require.

  Required environment variables (set in Vercel project settings):
    FIREBASE_PROJECT_ID
    FIREBASE_CLIENT_EMAIL
    FIREBASE_PRIVATE_KEY        ← copy verbatim from the service account JSON;
                                  Vercel preserves the \n escapes, which we
                                  unescape below before passing to Admin SDK.

  How to get the values:
    Firebase Console → Project settings → Service accounts →
    Generate new private key → download JSON → copy project_id, client_email,
    private_key into the three env vars above.
*/

const admin = require("firebase-admin");

function init(){
  if(admin.apps.length > 0){
    return admin.app();
  }

  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const rawKey = process.env.FIREBASE_PRIVATE_KEY;

  if(!projectId || !clientEmail || !rawKey){
    throw new Error(
      "Firebase Admin SDK is not configured. " +
      "Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY in Vercel."
    );
  }

  // Vercel stores newlines as literal \n in env vars; unescape so the PEM
  // parser sees real newlines. If the key already contains real newlines
  // (e.g., set via Vercel CLI with a heredoc), this no-ops.
  const privateKey = rawKey.replace(/\\n/g, "\n");

  return admin.initializeApp({
    credential: admin.credential.cert({
      projectId: projectId,
      clientEmail: clientEmail,
      privateKey: privateKey
    })
  });
}

module.exports = {
  init: init,
  getAuth: function(){ return admin.auth(init()); },
  getFirestore: function(){ return admin.firestore(init()); },
  FieldValue: admin.firestore.FieldValue,
  Timestamp: admin.firestore.Timestamp
};
