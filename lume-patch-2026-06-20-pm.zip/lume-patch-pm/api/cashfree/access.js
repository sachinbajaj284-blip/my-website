/*
  Server-trusted access check for Lume Live.

  Endpoint:
    GET /api/cashfree/access

  Authentication:
    Authorization: Bearer <firebase-id-token>

  Returns the set of SKUs the authenticated user has PAID for, sourced from
  Firestore (which is written only by the HMAC-verified webhook). The client
  uses this to gate assessment access — replacing the previous localStorage
  honour-system gate that anyone could bypass from DevTools.

  Required environment variables:
    FIREBASE_*  ← see api/_lib/firebase-admin.js
*/

const { getAuth, getFirestore } = require("../_lib/firebase-admin");

function json(res, status, body){
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.setHeader("Cache-Control", "private, no-store");
  res.end(JSON.stringify(body));
}

const DEFAULT_ALLOWED_ORIGINS = [
  "https://lumelive.co.in",
  "https://www.lumelive.co.in",
  "http://127.0.0.1:8765",
  "http://localhost:8765"
];

function allowedOrigins(){
  return new Set(DEFAULT_ALLOWED_ORIGINS.concat(
    String(process.env.LUME_ALLOWED_ORIGINS || "")
      .split(",")
      .map(function(origin){ return origin.trim(); })
      .filter(Boolean)
  ));
}

function setCors(req, res){
  const origin = req.headers.origin || "";
  if(origin && allowedOrigins().has(origin)){
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
}

module.exports = async function handler(req, res){
  setCors(req, res);

  if(req.method === "OPTIONS"){
    res.statusCode = 204;
    return res.end();
  }

  if(req.method !== "GET"){
    return json(res, 405, { error: "Method not allowed" });
  }

  // Pull the Firebase ID token. Reject anonymous traffic outright — this
  // endpoint must never reveal whether an order exists without proof of
  // identity.
  const authHeader = req.headers.authorization || "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if(!match){
    return json(res, 401, { error: "Missing bearer token" });
  }
  const idToken = match[1];

  let uid;
  try{
    const decoded = await getAuth().verifyIdToken(idToken, true);
    uid = decoded.uid;
  }catch(err){
    return json(res, 401, { error: "Invalid token" });
  }

  const db = getFirestore();
  try{
    const snapshot = await db.collection("lumelens_orders")
      .where("uid", "==", uid)
      .where("status", "==", "PAID")
      .get();

    const paidSkus = new Set();
    const orders = [];
    snapshot.forEach(function(doc){
      const data = doc.data();
      if(data && data.sku){
        paidSkus.add(data.sku);
        orders.push({
          order_id:  data.order_id,
          sku:       data.sku,
          amount:    data.amount,
          paid_at:   data.paid_at && typeof data.paid_at.toMillis === "function"
                       ? data.paid_at.toMillis()
                       : null
        });
      }
    });

    return json(res, 200, {
      uid: uid,
      paid_skus: Array.from(paidSkus),
      orders: orders,
      checked_at: Date.now()
    });
  }catch(err){
    // Composite index missing is the most likely cause of a Firestore error
    // here on first deploy — surface a useful message in logs.
    if(err && err.code === 9){
      console.error("[access] Missing Firestore composite index on (uid, status). Deploy firestore.indexes.json.");
    }else{
      console.error("[access] Firestore query failed", err);
    }
    return json(res, 500, { error: "Lookup failed" });
  }
};
