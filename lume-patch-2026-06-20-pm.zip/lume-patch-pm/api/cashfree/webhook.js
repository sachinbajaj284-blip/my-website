/*
  Cashfree payment webhook handler for Lume Live.

  Endpoint:
    POST /api/cashfree/webhook

  Configure in Cashfree dashboard:
    Webhooks → Add endpoint → https://lumelive.co.in/api/cashfree/webhook
    Events: subscribe to PAYMENT_SUCCESS_WEBHOOK at minimum (also
            PAYMENT_FAILED_WEBHOOK and PAYMENT_USER_DROPPED_WEBHOOK for
            observability).

  Required environment variables:
    CASHFREE_WEBHOOK_SECRET     ← copy from Cashfree webhook settings page
    FIREBASE_*                  ← see api/_lib/firebase-admin.js

  Security properties:
    - HMAC-SHA256 over (timestamp + raw body) using the webhook secret;
      rejects forged calls (Cashfree spec).
    - Replay window of 5 minutes (rejects old captured webhooks).
    - Idempotent: re-delivery of the same webhook does not double-write,
      and a PAID record cannot be downgraded to DROPPED/FAILED.
    - Server-trusted amount cross-check against the SKU price map; any
      mismatch is logged for follow-up but does not block recording.
*/

const crypto = require("crypto");
const { getFirestore, FieldValue } = require("../_lib/firebase-admin");

// Mirror of the SKU prices in create-order.js. Keep in sync if either changes.
const SKU_PRICES = {
  "student-full-report":         { amount: 999,  gated: true  },
  "lume-lens-working-profile":   { amount: 1999, gated: true  },
  "intro-session":               { amount: 49,   gated: false },
  "parents-handbook":            { amount: 199,  gated: false },
  "career-intelligence-roadmap": { amount: 1499, gated: true  }
};

function readRawBody(req){
  return new Promise(function(resolve, reject){
    const chunks = [];
    req.on("data", function(chunk){ chunks.push(chunk); });
    req.on("end", function(){
      try{ resolve(Buffer.concat(chunks).toString("utf8")); }
      catch(err){ reject(err); }
    });
    req.on("error", reject);
  });
}

function verifySignature(rawBody, timestamp, secret, receivedSignature){
  if(!rawBody || !timestamp || !secret || !receivedSignature) return false;
  const signedPayload = String(timestamp) + rawBody;
  const computed = crypto.createHmac("sha256", secret).update(signedPayload).digest("base64");
  const a = Buffer.from(String(receivedSignature));
  const b = Buffer.from(computed);
  if(a.length !== b.length) return false;
  try{ return crypto.timingSafeEqual(a, b); }
  catch(err){ return false; }
}

function inferStatus(eventType, payload){
  const upper = String(eventType || "").toUpperCase();
  const paymentStatus = String(payload?.data?.payment?.payment_status || "").toUpperCase();
  if(upper.includes("SUCCESS") || paymentStatus === "SUCCESS") return "PAID";
  if(upper.includes("FAILED")  || paymentStatus === "FAILED")  return "FAILED";
  if(upper.includes("DROPPED") || upper.includes("CANCELLED")) return "DROPPED";
  if(upper.includes("REFUND"))                                  return "REFUNDED";
  return "PENDING";
}

module.exports = async function handler(req, res){
  // Webhooks are not cross-origin and don't need CORS. Reject anything other
  // than POST to keep the endpoint quiet to scanners.
  if(req.method !== "POST"){
    res.statusCode = 405;
    return res.end(JSON.stringify({ error: "Method not allowed" }));
  }

  const secret = process.env.CASHFREE_WEBHOOK_SECRET;
  if(!secret){
    console.error("[webhook] CASHFREE_WEBHOOK_SECRET not set");
    res.statusCode = 500;
    return res.end(JSON.stringify({ error: "Webhook secret not configured" }));
  }

  let rawBody;
  try{ rawBody = await readRawBody(req); }
  catch(err){
    res.statusCode = 400;
    return res.end(JSON.stringify({ error: "Body read failed" }));
  }

  const signature = req.headers["x-webhook-signature"] || "";
  const timestamp = req.headers["x-webhook-timestamp"] || "";

  if(!verifySignature(rawBody, timestamp, secret, signature)){
    console.warn("[webhook] Signature verification failed", {
      hasSignature: Boolean(signature),
      hasTimestamp: Boolean(timestamp)
    });
    res.statusCode = 401;
    return res.end(JSON.stringify({ error: "Invalid signature" }));
  }

  // Replay protection — reject webhooks that are more than 5 minutes old or
  // more than 5 minutes in the future (clock skew tolerance).
  const ts = parseInt(timestamp, 10);
  if(isNaN(ts) || Math.abs(Date.now() - ts) > 5 * 60 * 1000){
    console.warn("[webhook] Timestamp outside replay window", { timestamp });
    res.statusCode = 401;
    return res.end(JSON.stringify({ error: "Timestamp out of range" }));
  }

  let payload;
  try{ payload = JSON.parse(rawBody); }
  catch(err){
    res.statusCode = 400;
    return res.end(JSON.stringify({ error: "Invalid JSON body" }));
  }

  const eventType = payload.type || payload.event || "";
  const data = payload.data || payload;
  const order = data.order || {};
  const orderId = order.order_id || data.order_id || "";

  if(!orderId){
    res.statusCode = 400;
    return res.end(JSON.stringify({ error: "Missing order_id" }));
  }

  const orderTags = order.order_tags || {};
  const sku = String(orderTags.sku || "");
  const skuConfig = SKU_PRICES[sku] || null;
  const expectedAmount = skuConfig ? skuConfig.amount : null;
  const orderAmount = Number(order.order_amount || data.order_amount || 0);
  const amountMatches = expectedAmount === null || orderAmount === expectedAmount;
  const status = inferStatus(eventType, payload);

  const db = getFirestore();
  const docRef = db.collection("lumelens_orders").doc(orderId);

  try{
    await db.runTransaction(async function(tx){
      const existing = await tx.get(docRef);
      const existingData = existing.exists ? existing.data() : null;
      const existingStatus = existingData ? existingData.status : null;

      // Idempotency: once an order is PAID, only a REFUNDED event can change
      // its status. PAID is terminal-positive; downgrades are ignored.
      if(existingStatus === "PAID" && status !== "REFUNDED"){
        return;
      }

      // Build the update. Server-controlled fields override anything the
      // webhook might claim. Customer PII is stored here for support use
      // (founder-side dashboard later); it is NEVER returned to the public
      // order-status endpoint.
      const update = {
        order_id:          orderId,
        cf_order_id:       order.cf_order_id || (existingData && existingData.cf_order_id) || "",
        sku:               sku,
        amount:            orderAmount,
        expected_amount:   expectedAmount,
        amount_matches:    amountMatches,
        currency:          order.order_currency || "INR",
        status:            status,
        event_type:        eventType,
        gated_product:     skuConfig ? skuConfig.gated : false,
        uid:               String(orderTags.uid || (existingData && existingData.uid) || ""),
        customer_phone:    (order.customer_details && order.customer_details.customer_phone) || "",
        customer_name:     (order.customer_details && order.customer_details.customer_name)  || "",
        customer_email:    (order.customer_details && order.customer_details.customer_email) || "",
        last_webhook_at:   FieldValue.serverTimestamp(),
        last_event_type:   eventType,
        raw_webhook:       payload
      };

      if(status === "PAID" && existingStatus !== "PAID"){
        update.paid_at = FieldValue.serverTimestamp();
      }
      if(status === "REFUNDED"){
        update.refunded_at = FieldValue.serverTimestamp();
      }
      if(!existingData){
        update.created_at = FieldValue.serverTimestamp();
      }

      tx.set(docRef, update, { merge: true });
    });

    if(!amountMatches){
      console.warn("[webhook] Amount mismatch recorded", {
        orderId, sku, expected: expectedAmount, actual: orderAmount
      });
    }

    res.statusCode = 200;
    return res.end(JSON.stringify({ ok: true, order_id: orderId, status: status }));
  }catch(err){
    console.error("[webhook] Firestore transaction failed", err);
    // Return 5xx so Cashfree retries — this is correct behaviour for
    // transient infrastructure errors. The transaction is idempotent, so
    // a retry will not produce duplicate state.
    res.statusCode = 500;
    return res.end(JSON.stringify({ error: "Storage error" }));
  }
};
