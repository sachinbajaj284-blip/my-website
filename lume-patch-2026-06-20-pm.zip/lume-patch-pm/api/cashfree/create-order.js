/*
  Deployable Cashfree create-order endpoint for Lume Live.

  Endpoint:
  /api/cashfree/create-order

  Required environment variables:
  CASHFREE_CLIENT_ID=...
  CASHFREE_CLIENT_SECRET=...
  CASHFREE_ENV=production or sandbox
  CASHFREE_API_VERSION=2025-01-01
  LUME_PUBLIC_BASE_URL=https://lumelive.co.in
*/

const crypto = require("crypto");
const { getAuth, getFirestore, FieldValue } = require("../_lib/firebase-admin");

const SKU_PRICES = {
  "student-full-report":         { amount: 999,  label: "Lume Live Full Clarity Report",           alias: "student999",  gated: true,  requiresAuth: true  },
  "lume-lens-working-profile":   { amount: 1999, label: "Lume Lens Working Profile",               alias: "lens1999",    gated: true,  requiresAuth: true  },
  "intro-session":               { amount: 49,   label: "Introductory Guidance Session",           alias: "intro49",     gated: false, requiresAuth: false },
  "parents-handbook":            { amount: 199,  label: "Parents Career Handbook",                 alias: "parents199",  gated: false, requiresAuth: false },
  "career-intelligence-roadmap": { amount: 1499, label: "Career Intelligence Detailed Roadmap",    alias: "roadmap1499", gated: true,  requiresAuth: true  }
};

function json(res, status, body){
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(body));
}

const DEFAULT_ALLOWED_ORIGINS = [
  "https://lumelive.co.in",
  "https://www.lumelive.co.in",
  "http://127.0.0.1:8765",
  "http://localhost:8765"
];

function allowedOrigins(){
  return new Set(DEFAULT_ALLOWED_ORIGINS.concat(
    String(process.env.LUME_ALLOWED_ORIGINS || "")
      .split(",")
      .map(function(origin){ return origin.trim(); })
      .filter(Boolean)
  ));
}

function setCors(req, res){
  const origin = req.headers.origin || "";
  if(origin && allowedOrigins().has(origin)){
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function readBody(req){
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", chunk => { raw += chunk; });
    req.on("end", () => {
      try{ resolve(raw ? JSON.parse(raw) : {}); }
      catch(err){ reject(err); }
    });
    req.on("error", reject);
  });
}

module.exports = async function handler(req, res){
  setCors(req, res);

  if(req.method === "OPTIONS"){
    res.statusCode = 204;
    return res.end();
  }

  if(req.method !== "POST"){
    return json(res, 405, { error: "Method not allowed" });
  }

  const clientId = process.env.CASHFREE_CLIENT_ID;
  const clientSecret = process.env.CASHFREE_CLIENT_SECRET;
  if(!clientId || !clientSecret){
    return json(res, 500, { error: "Cashfree credentials are not configured." });
  }

  let body;
  try{ body = await readBody(req); }
  catch(err){ return json(res, 400, { error: "Invalid JSON body." }); }

  const sku = String(body.sku || "");
  const product = SKU_PRICES[sku];
  if(!product){
    return json(res, 400, { error: "Unknown payment item." });
  }

  // For gated products (assessment, lens, roadmap) the customer must be
  // signed in with Firebase. We verify the ID token here so the uid we
  // attach to the order is server-trusted, not client-claimed. Webhook-side
  // Firestore writes use this uid for the access-check query.
  let uid = "";
  const authHeader = req.headers.authorization || "";
  const tokenMatch = authHeader.match(/^Bearer\s+(.+)$/i);
  if(tokenMatch){
    try{
      const decoded = await getAuth().verifyIdToken(tokenMatch[1], true);
      uid = decoded.uid;
    }catch(err){
      // Token present but invalid is a hard error for gated products,
      // ignored for ungated ones.
      if(product.requiresAuth){
        return json(res, 401, { error: "Sign-in expired. Please sign in again." });
      }
    }
  }
  if(product.requiresAuth && !uid){
    return json(res, 401, { error: "Sign-in required for this purchase." });
  }

  const customer = body.customer || {};
  const phone = String(customer.phone || "").replace(/\D/g, "").slice(-10);
  const email = String(customer.email || "hello@lumelive.co.in").slice(0, 120);
  const name = String(customer.name || "Lume Live Customer").slice(0, 80);
  if(!phone && sku !== "parents-handbook" && sku !== "intro-session"){
    return json(res, 400, { error: "Customer phone is required." });
  }

  const env = (process.env.CASHFREE_ENV || "production").toLowerCase();
  const base = env === "sandbox" ? "https://sandbox.cashfree.com/pg" : "https://api.cashfree.com/pg";
  const publicBase = process.env.LUME_PUBLIC_BASE_URL || "https://lumelive.co.in";
  // Use a full UUID for the order suffix. The previous timestamp + 5-char
  // Math.random produced partially predictable IDs (~60M brute-force space
  // against a guessable time window), which mattered because anyone with an
  // order_id can hit /api/cashfree/order-status. UUID gives 122 bits of
  // entropy and is unenumerable. Strip hyphens to fit Cashfree's 45-char
  // order_id limit comfortably alongside the prefix and alias.
  const suffix = crypto.randomUUID().replace(/-/g, "");
  const orderId = ("lume_" + product.alias + "_" + suffix).slice(0, 45);
  const requestId = crypto.randomUUID();
  const returnUrl = body.returnUrl || (publicBase + "/payment-return.html?order_id={order_id}");

  const cashfreePayload = {
    order_id: orderId,
    order_amount: product.amount,
    order_currency: "INR",
    order_note: product.label,
    customer_details: {
      customer_id: phone || ("guest_" + Date.now()),
      customer_name: name,
      customer_email: email,
      customer_phone: phone || "9999999999"
    },
    order_meta: {
      return_url: returnUrl,
      notify_url: process.env.CASHFREE_NOTIFY_URL || undefined,
      payment_methods: "cc,dc,upi,nb,app,paylater"
    },
    order_tags: {
      sku: sku,
      uid: uid,
      source: "lume-live-website"
    }
  };

  const response = await fetch(base + "/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-client-id": clientId,
      "x-client-secret": clientSecret,
      "x-api-version": process.env.CASHFREE_API_VERSION || "2025-01-01",
      "x-request-id": requestId,
      "x-idempotency-key": requestId
    },
    body: JSON.stringify(cashfreePayload)
  });

  const data = await response.json().catch(() => ({}));
  if(!response.ok){
    return json(res, response.status, { error: "Cashfree order creation failed.", details: data });
  }

  // Persist a CREATED record so the webhook has something to merge into and
  // so support tooling can see in-flight orders. Failures here are logged
  // but non-fatal — the webhook itself uses { merge: true } and will create
  // the doc if it doesn't exist yet.
  try{
    const db = getFirestore();
    await db.collection("lumelens_orders").doc(orderId).set({
      order_id:        orderId,
      cf_order_id:     data.cf_order_id || "",
      sku:             sku,
      amount:          product.amount,
      expected_amount: product.amount,
      currency:        "INR",
      status:          "CREATED",
      gated_product:   product.gated,
      uid:             uid,
      customer_phone:  phone,
      customer_name:   name,
      customer_email:  email,
      created_at:      FieldValue.serverTimestamp()
    }, { merge: true });
  }catch(err){
    console.warn("[create-order] Failed to persist CREATED record", err && err.message);
  }

  return json(res, 200, {
    order_id: data.order_id,
    cf_order_id: data.cf_order_id,
    payment_session_id: data.payment_session_id || data.payment_sessions_id
  });
};
