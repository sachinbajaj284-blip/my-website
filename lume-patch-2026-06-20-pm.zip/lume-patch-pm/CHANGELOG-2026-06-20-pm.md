# Lume Live — Day 1 Afternoon Fixes (2026-06-20)

This patch closes the single biggest finding from the morning audit: the
client-side `localStorage` payment gate that anyone with DevTools could
bypass in one line. After this lands, the source of truth for "is this
SKU paid for this user" is Firestore, written only by a HMAC-verified
Cashfree webhook.

**Before applying:** read `FIRESTORE-SETUP.md` end to end. There are
four new Vercel environment variables, one Firestore database to enable,
a service account to create, security rules and indexes to deploy, and a
Cashfree webhook URL to register. Skipping any step leaves the site in
a broken state.

## Files in this patch

### New

```
api/_lib/firebase-admin.js          ← Shared Admin SDK init
api/cashfree/webhook.js             ← HMAC-verified Cashfree webhook
api/cashfree/access.js              ← Auth'd access-check endpoint
firestore.rules                     ← Server-only writes; read-your-own
firestore.indexes.json              ← Composite index on (uid, status)
firebase.json                       ← Firebase CLI config
FIRESTORE-SETUP.md                  ← Step-by-step deployment guide
```

### Modified

```
api/cashfree/create-order.js        ← Verifies Firebase ID token; writes CREATED record
cashfree-payments.js                ← Server-backed access check; localStorage no longer authoritative
payment-return.html                 ← Waits for webhook confirmation before redirect
package.json                        ← firebase-admin dependency
.gitignore                          ← Firebase service-account JSON patterns
index.html                          ← Dispatches lume:auth-ready event
assessment.html                     ← Dispatches lume:auth-ready event
for-working-professionals.html      ← Dispatches lume:auth-ready event
```

## What changed and why

### The security boundary moved from the browser to the server

`lumeCashfreeHasAccess(sku)` used to read directly from `localStorage`.
Anyone could open DevTools and run:

```js
localStorage.setItem("lumeCashfreeAccess",
  JSON.stringify({"student-full-report":{status:"PAID"}}));
```

…to unlock ₹999 of paid content. After this patch, the same function:

1. Returns false unless the user is signed in with Firebase.
2. Returns false unless the in-memory `serverPaidSkus` cache contains the
   SKU AND the cache's `uid` matches the signed-in `uid`.
3. The cache is populated only by `lumeCashfreeRefreshAccess()`, which
   calls `/api/cashfree/access` with the user's Firebase ID token and
   trusts the server's response.
4. The server queries Firestore `lumelens_orders` for rows where
   `uid == request.uid AND status == "PAID"`.
5. Those rows are written only by `api/cashfree/webhook.js`, which
   requires a valid Cashfree HMAC signature.

The localStorage record is still written for UX hints on the payment-return
page, but `hasAccess()` no longer reads it. Tampering does nothing.

### How the new chain handles the "user closes the tab" case

Old flow: user paid → Cashfree redirected to `payment-return.html` → the
page polled `/api/cashfree/order-status` and on PAID wrote to localStorage.
If the user closed the tab before the redirect resolved, the website never
learned about the payment, and you got a WhatsApp message.

New flow: user paid → Cashfree fires the webhook server-to-server,
independently of the user's browser → webhook verifies HMAC → writes
Firestore. The browser is no longer part of the trust chain. The user can
close the tab, change phones, clear cache — when they next sign in, the
access endpoint will return their paid SKUs from Firestore.

### Webhook idempotency

Cashfree retries on any 5xx response and occasionally re-delivers
successful webhooks. The handler uses a Firestore transaction that:

- Reads the existing order record (if any)
- If `status === "PAID"` already, returns immediately (no double-write,
  no duplicate `paid_at` timestamp, no duplicate side effects)
- Otherwise merges the new state with the existing record

Replay attacks are blocked by a 5-minute timestamp window on top of the
HMAC verification.

### Auth integration

The three large HTML files now dispatch a `lume:auth-ready` event after
`renderAuthUser` fires. `cashfree-payments.js` listens for this and
automatically calls `lumeCashfreeRefreshAccess()` whenever auth state
changes. This means a paid user signing in on a fresh device sees the
access state populated within ~500ms of sign-in.

For pages that don't yet have the event dispatch (e.g., `career-intelligence.html`),
the access check can be triggered manually:

```js
if(window.lumeCashfreeRefreshAccess){ window.lumeCashfreeRefreshAccess(); }
```

### `create-order.js` now requires sign-in for gated SKUs

The `SKU_PRICES` map now has a `requiresAuth` flag:

- `student-full-report` → required
- `lume-lens-working-profile` → required
- `career-intelligence-roadmap` → required
- `intro-session` → not required (just a session booking)
- `parents-handbook` → not required (just a PDF)

For gated SKUs, the endpoint refuses to create an order without a valid
Firebase ID token. The `uid` from that token is stamped into
`order_tags.uid` and trusted from there onward.

### `payment-return.html` waits for the webhook

After Cashfree confirms PAID, the page no longer redirects immediately.
It calls `lumeCashfreeRefreshAccess()` in a loop (every 2 seconds, up to
30 seconds) until Firestore reports the SKU as paid. Then it redirects.

This handles the ~2-5 second window where Cashfree has confirmed the
payment to the user's browser but the webhook hasn't yet arrived at our
server. The user sees "Cashfree confirmed payment. Waiting for our
records to sync..." for at most a few seconds, then continues.

If 30 seconds elapse without webhook confirmation (rare — usually means
Vercel is cold-starting or the webhook URL is misconfigured), the user
sees a manual "tap Continue or message us on WhatsApp" message. This is
better than the alternative of unlocking access prematurely.

## What this does NOT change

The PDF report is still generated client-side via jsPDF. Anyone who
gets past the assessment gate can still see the generated PDF in their
browser. The right architectural fix is server-side report generation
behind an authenticated endpoint — that's a separate phase of work and
not in scope here.

**What this patch does close**: the trivial "paste one line in DevTools"
bypass. After this lands, an attacker would need to either forge a
Cashfree webhook (requires the webhook secret) or find a Firestore rules
bug. Both are real attacker effort.

## Smoke test checklist

Detailed in `FIRESTORE-SETUP.md` § Step 6. Quick version:

1. Complete a sandbox payment as a signed-in user.
2. Verify a Firestore document was written with `status: "PAID"`.
3. Open a fresh incognito window, sign in with a different account,
   attempt the localStorage bypass — assessment must stay locked.
4. Replay the webhook from Cashfree dashboard — verify single Firestore
   write, `paid_at` unchanged.

## Deployment order

1. Apply this patch to the repo.
2. Do the four environment-variable additions in Vercel.
3. Deploy Firestore rules and indexes.
4. Wait for the composite index to finish building (Firebase Console).
5. Add the Cashfree webhook URL and copy the secret to Vercel.
6. Deploy the website to Vercel.
7. Run the smoke tests.

If you deploy out of order — most commonly, deploying the site before
the Firestore index finishes building — `/api/cashfree/access` will
return 500 and signed-in paid users will see the unlock state lag.
Wait for the green checkmark in Firebase Console before flipping the
production deploy.
