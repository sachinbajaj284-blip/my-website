(function(){
  "use strict";

  var DEFAULTS = {
    mode: "production",
    createOrderEndpoint: "/api/cashfree/create-order",
    orderStatusEndpoint: "/api/cashfree/order-status",
    accessEndpoint:      "/api/cashfree/access",
    redirectTarget: "_self",
    whatsappNumber: "917015671280"
  };

  // In-memory cache of server-verified paid SKUs for the current signed-in
  // user. This is the ONLY trusted source. The previous localStorage record
  // is no longer used as a security boundary — it's kept as a write-through
  // hint for the payment-return page only.
  var serverPaidSkus = {};   // { sku: { paid_at, order_id } }
  var serverPaidUid = "";    // The uid that serverPaidSkus reflects.
  var refreshPromise = null;

  function getConfig(){
    var pageConfig = window.LUME_CASHFREE || {};
    var cfg = {};
    Object.keys(DEFAULTS).forEach(function(key){ cfg[key] = DEFAULTS[key]; });
    Object.keys(pageConfig).forEach(function(key){ cfg[key] = pageConfig[key]; });
    return cfg;
  }

  function notify(message){
    if(typeof window.showToast === "function"){ window.showToast(message); return; }
    if(typeof window.toast === "function"){ window.toast(message); return; }
    window.alert(message);
  }

  function safeOpen(url){
    var opened = window.open(url, "_blank", "noopener");
    if(!opened){ window.location.href = url; }
  }

  function waMessage(options){
    var lines = [
      "Hi Lume Live!",
      "I want to complete payment for " + (options.label || "a Lume Live service") + ".",
      "Amount: Rs " + (options.amount || ""),
      options.customerName ? "Name: " + options.customerName : "",
      options.customerPhone ? "WhatsApp: " + options.customerPhone : "",
      options.customerEmail ? "Email: " + options.customerEmail : "",
      "Please help me complete the payment and confirm access."
    ].filter(Boolean);
    return lines.join("\n");
  }

  function fallback(options){
    if(options && typeof options.onFallback === "function"){
      return options.onFallback(options);
    }
    var cfg = getConfig();
    safeOpen("https://wa.me/" + cfg.whatsappNumber + "?text=" + encodeURIComponent(waMessage(options || {})));
  }

  function paymentUnavailable(message, options, detail){
    var suffix = " Please try again from the live website. The WhatsApp Pay backup stays available below if you need manual support.";
    notify(message + suffix);
    if(options && (options.allowWhatsappFallback === true || options.autoWhatsappFallback === true)){
      fallback(options);
      markPaymentStarted(options, { fallback: true, error: String(detail && detail.message || detail || "") }, {});
      return Promise.resolve({ ok: false, fallback: true, error: detail || null });
    }
    return Promise.resolve({ ok: false, fallback: false, error: detail || null });
  }

  function browserCanUseBackend(cfg){
    if(!cfg.createOrderEndpoint){ return false; }
    if(window.location.protocol === "file:"){ return false; }
    return true;
  }

  function buildReturnUrl(options){
    if(options.returnUrl){ return options.returnUrl; }
    var cfg = getConfig();
    if(cfg.returnUrl){ return cfg.returnUrl; }
    var origin = cfg.publicBaseUrl || cfg.publicBase || "https://lumelive.co.in";
    var continuePath = encodeURIComponent((window.location.pathname || "/assessment.html") + (window.location.search || "") + (window.location.hash || ""));
    var sku = encodeURIComponent(options.sku || "");
    return origin + "/payment-return.html?order_id={order_id}&sku=" + sku + "&continue=" + continuePath;
  }

  function markPaymentStarted(options, data, result){
    if(typeof options.onStarted === "function"){
      options.onStarted(data || {}, result || {});
    }
  }

  // ──────────────────────────────────────────────────────────────────────
  // Server-trusted access check
  // ──────────────────────────────────────────────────────────────────────

  function currentIdToken(){
    var user = window.currentFirebaseUser;
    if(!user || typeof user.getIdToken !== "function") return Promise.resolve("");
    return user.getIdToken().catch(function(){ return ""; });
  }

  function fetchPaidSkus(){
    return currentIdToken().then(function(token){
      if(!token){
        return { paid_skus: [], orders: [], uid: "" };
      }
      var cfg = getConfig();
      return fetch(cfg.accessEndpoint, {
        method: "GET",
        headers: { "Authorization": "Bearer " + token }
      }).then(function(res){
        if(!res.ok){ throw new Error("access-check failed: " + res.status); }
        return res.json();
      });
    });
  }

  // Public: ask the server which SKUs the signed-in user has paid for and
  // refresh the in-memory cache. Returns a promise for callers that want to
  // await. Safe to call multiple times — concurrent calls share one fetch.
  window.lumeCashfreeRefreshAccess = function(){
    if(refreshPromise) return refreshPromise;
    refreshPromise = fetchPaidSkus().then(function(data){
      serverPaidUid = data.uid || "";
      serverPaidSkus = {};
      (data.paid_skus || []).forEach(function(sku){
        var order = (data.orders || []).find(function(o){ return o.sku === sku; }) || {};
        serverPaidSkus[sku] = { paid_at: order.paid_at || null, order_id: order.order_id || "" };
      });
      try{ window.dispatchEvent(new CustomEvent("lume:cashfree-access-updated", { detail: { paid_skus: data.paid_skus || [] } })); }
      catch(err){}
      return data.paid_skus || [];
    }).catch(function(err){
      console.warn("[Lume Cashfree] access refresh failed", err);
      return [];
    }).then(function(result){
      refreshPromise = null;
      return result;
    });
    return refreshPromise;
  };

  // Public: sync check the in-memory cache. Returns true only if the server
  // confirmed this SKU for the currently signed-in user. localStorage is no
  // longer consulted, so tampering with `lumeCashfreeAccess` does nothing.
  window.lumeCashfreeHasAccess = function(sku){
    if(!sku) return false;
    var user = window.currentFirebaseUser;
    if(!user || !user.uid) return false;
    if(serverPaidUid && serverPaidUid !== user.uid) return false;
    return Boolean(serverPaidSkus[sku]);
  };

  // Backward-compatible no-op. Previously this wrote to localStorage and
  // granted access. That bypass is now closed; the only path to access is
  // via the webhook → Firestore → access endpoint chain.
  window.lumeCashfreeGrantAccess = function(sku, details){
    void sku; void details;
    if(typeof window.lumeCashfreeRefreshAccess === "function"){
      window.lumeCashfreeRefreshAccess();
    }
  };

  window.lumeCashfreeGetConfig = getConfig;

  // Trigger a refresh when Firebase auth resolves. The page is expected to
  // dispatch `lume:auth-ready` after `onAuthStateChanged` fires (the existing
  // renderAuthUser code does this via the renderAuthUser → saUseAccountProgress
  // chain; we also listen for a dedicated event for cleanliness).
  window.addEventListener("lume:auth-ready", function(){
    if(window.currentFirebaseUser){
      window.lumeCashfreeRefreshAccess();
    }else{
      serverPaidSkus = {};
      serverPaidUid = "";
    }
  });

  // ──────────────────────────────────────────────────────────────────────
  // Checkout
  // ──────────────────────────────────────────────────────────────────────

  window.lumeCashfreePay = function(options){
    options = options || {};
    var cfg = getConfig();

    if(!browserCanUseBackend(cfg)){
      return paymentUnavailable("Cashfree checkout needs the live payment backend.", options, "backend-unavailable");
    }

    if(typeof window.Cashfree !== "function"){
      return paymentUnavailable("Cashfree checkout is still loading.", options, "sdk-unavailable");
    }

    var payload = {
      sku: options.sku || "",
      amount: Number(options.amount || 0),
      label: options.label || "",
      customer: {
        name: options.customerName || "",
        phone: options.customerPhone || "",
        email: options.customerEmail || ""
      },
      notes: options.notes || {},
      pageUrl: window.location.href,
      returnUrl: buildReturnUrl(options)
    };

    // Attach Firebase ID token if the user is signed in. The server requires
    // it for gated SKUs and uses it to stamp the order with a trusted uid.
    return currentIdToken().then(function(token){
      var headers = { "Content-Type": "application/json" };
      if(token){ headers["Authorization"] = "Bearer " + token; }
      return fetch(cfg.createOrderEndpoint, {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload)
      });
    })
    .then(function(res){
      if(!res.ok){
        return res.json().catch(function(){ return {}; }).then(function(err){
          throw new Error(err.error || ("Cashfree order creation failed: " + res.status));
        });
      }
      return res.json();
    })
    .then(function(data){
      var sessionId = data.payment_session_id || data.paymentSessionId || data.payment_sessions_id;
      if(!sessionId){ throw new Error("Cashfree order response did not include payment_session_id."); }
      var cashfree = window.Cashfree({ mode: cfg.mode || "production" });
      markPaymentStarted(options, data, { stage: "checkout-opened" });
      return cashfree.checkout({
        paymentSessionId: sessionId,
        redirectTarget: options.redirectTarget || cfg.redirectTarget || "_modal"
      }).then(function(result){
        if(typeof options.onCompleted === "function"){ options.onCompleted(data, result || {}); }
        return { ok: true, order: data, result: result };
      });
    })
    .catch(function(err){
      console.warn("[Lume Cashfree]", err);
      return paymentUnavailable(err.message || "Cashfree checkout could not start.", options, err);
    });
  };

  if(typeof document !== "undefined" && document.documentElement){
    document.documentElement.setAttribute("data-lume-cashfree", "ready");
  }
  try{ window.dispatchEvent(new CustomEvent("lume:cashfree-ready")); }
  catch(err){}
})();
